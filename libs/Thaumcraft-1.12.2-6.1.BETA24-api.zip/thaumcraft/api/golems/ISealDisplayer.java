package thaumcraft.api.golems;

/**
 * Items using this interface will make golem seals visible in the world while held
 * 
 * @author azanor
 *
 */
public interface ISealDisplayer {

}
