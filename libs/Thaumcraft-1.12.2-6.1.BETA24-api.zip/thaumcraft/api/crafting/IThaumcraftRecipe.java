package thaumcraft.api.crafting;

public interface IThaumcraftRecipe  {
	public String getResearch();
	public String getGroup();
}
